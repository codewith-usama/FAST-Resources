﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartsUnlimited.Shared
{
    public class TaxService
    {
        static public decimal CalculateTax(decimal taxable, string postalCode)
        {
            return taxable * (decimal).2;
        }
    }
}

